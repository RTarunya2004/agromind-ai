# AgroMind AI — Research Model Website Integration

This bundle integrates the saved reconstructed hybrid research run into the farmer website.

## Start backend
From this directory:

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Open `frontend/index.html` in a browser. The page calls the local API at `http://127.0.0.1:8000`.

## Model and limitations
The API loads `backend/model_artifacts/best_reconstructed_hybrid.pth` and the model class, 80-column feature order, crop label encoder, and training metrics from the supplied research training archive. This is the reconstructed TabNet-inspired mask module + Transformer classifier, not an exact original TabNet checkpoint (that artifact was not supplied).

The form supplies seven numeric and three categorical fields. The training data has additional fields that are not available in the farmer form (including crop duration, sow/harvest, crop type, and upper-range fields); the integration sets those absent fields to zero and returns a warning. Therefore this is a connected prototype, not a validated field recommendation system. Model scores are not calibrated probabilities of crop success. The model may be affected by target leakage in the dataset and should undergo a leakage-safe evaluation before production deployment.

Do not present the paper-reported scores or offline test scores as live farm accuracy.
